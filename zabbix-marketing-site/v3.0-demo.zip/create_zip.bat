@echo off
title ZIP Builder
echo Creating autoshutdown.zip...

powershell -Command "
$zip = 'autoshutdown.zip';
if (Test-Path $zip) { Remove-Item $zip };
Compress-Archive -Path * -DestinationPath $zip -CompressionLevel Optimal;
Write-Host '[+] ZIP Created: autoshutdown.zip' -ForegroundColor Green
"

echo.
echo Done! Ready for distribution.
pause