@echo off
title Auto Shutdown Tool
color 0A

echo ========================================
echo   Auto Shutdown Timer Downloaded!
echo ========================================
echo.

REM Check if Python exists
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Installing Python Mini...
    powershell -c "iwr -useb https://github.com/indygreg/python-build-standalone/releases/download/python-3.11.5/python-3.11.5-embed-amd64.zip -o python.zip; Expand-Archive python.zip -Force; python.exe autoshutdown.py"
    exit /b
)

REM Run your Python script with 5 minute timer
echo [START] Running shutdown timer (5 minutes)...
python autoshutdown.py 300

echo.
echo [DONE] Press any key to exit...
pause >nul