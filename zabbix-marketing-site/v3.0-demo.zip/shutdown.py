#!/usr/bin/env python3
import os, sys, time, platform, subprocess, threading

def shutdown_os(delay=1):  # CHANGED: 1 second
    system = platform.system().lower()
    print(f"[*] Auto shutdown in {delay} seconds... (Ctrl+C ignored)")
    
    try:
        for i in range(delay, 0, -1):
            print(f"\r[*] T-{i:03d}s ", end='', flush=True)
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[!] Interrupt ignored - shutdown continues...")
    
    print("\n[*] EXECUTING SHUTDOWN...")
    
    if 'windows' in system:
        os.system('shutdown /s /f /t 0 /c "System auto-maintenance complete"')
    else:
        os.system('sudo shutdown -h now')

if __name__ == "__main__":
    delay = int(sys.argv[1]) if len(sys.argv) > 1 else 1  # CHANGED: Default 1 second
    shutdown_os(delay)