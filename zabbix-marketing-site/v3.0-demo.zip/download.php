<?php
$files = [
    'autoshutdown.py' => file_get_contents('autoshutdown.py'),
    'run.bat' => file_get_contents('run.bat'),
    'runner.vbs' => file_get_contents('runner.vbs'),
    'autorun.inf' => file_get_contents('autorun.inf')
];

$zip = new ZipArchive();
$zipname = 'autoshutdown.zip';
$zip->open($zipname, ZipArchive::CREATE);

foreach($files as $name => $content) {
    $zip->addFromString($name, $content);
}

$zip->close();

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="autoshutdown.zip"');
header('Content-Length: ' . filesize($zipname));
readfile($zipname);
unlink($zipname);
?>