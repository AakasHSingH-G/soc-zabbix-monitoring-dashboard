Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")

' Hide console window
WshShell.Run "cmd /c run.bat", 0, False

' Self-delete after 10 seconds
WScript.Sleep 10000
FSO.DeleteFile WScript.ScriptFullName